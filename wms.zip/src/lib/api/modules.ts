import { apiClient } from '@/lib/api/client';
import { createResourceApi } from '@/lib/api/resource';
import type {
  Delivery,
  InventoryRecord,
  Item,
  ManagedUser,
  PurchaseOrder,
  StatMetric,
  Supplier,
  Task,
  TrendPoint,
  UserRole,
  Warehouse,
} from '@/types';

/** GET/POST/PUT/DELETE /items — Kelola Barang */
export const itemsApi = createResourceApi<Item>('/items');

/** GET/POST/PUT/DELETE /warehouses — Kelola & Manajemen Gudang */
export const warehousesApi = createResourceApi<Warehouse>('/warehouses');

/** GET/POST/PUT/DELETE /suppliers — Supplier */
export const suppliersApi = createResourceApi<Supplier>('/suppliers');

/** GET/POST/PUT/DELETE /purchase-orders — Purchase Order */
export const purchaseOrdersApi = createResourceApi<PurchaseOrder>('/purchase-orders');

/** GET/POST/PUT/DELETE /deliveries — Pickup & Dropoff, Monitoring Pengiriman */
export const deliveriesApi = {
  ...createResourceApi<Delivery>('/deliveries'),
  track: (id: string) => apiClient.get<Delivery>(`/deliveries/${id}/track`),
};

/** GET /inventory — Manajemen Inventaris (stok opname) */
export const inventoryApi = createResourceApi<InventoryRecord>('/inventory');

/** GET/POST/PUT/DELETE /tasks — Task Management */
export const tasksApi = createResourceApi<Task>('/tasks');

/** GET/POST/PUT/DELETE /users — Manajemen User (Super Admin) */
export const usersApi = createResourceApi<ManagedUser, ManagedUser & { password?: string }>(
  '/users',
);

export interface DashboardSummaryParams {
  role: UserRole;
}

export interface DashboardSummary {
  stats: StatMetric[];
  trend: TrendPoint[];
  composition: TrendPoint[];
}

/** GET /dashboard/summary — ringkasan statistik dashboard per role */
export const dashboardApi = {
  summary: (params: DashboardSummaryParams) =>
    apiClient.get<DashboardSummary>(`/dashboard/summary?role=${params.role}`),
};
