import { apiClient } from '@/lib/api/client';
import type { PaginatedResult } from '@/types';

export interface ListParams {
  page?: number;
  pageSize?: number;
  search?: string;
  [key: string]: string | number | undefined;
}

function buildQuery(params: ListParams = {}): string {
  const searchParams = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== '') {
      searchParams.set(key, String(value));
    }
  });
  const query = searchParams.toString();
  return query ? `?${query}` : '';
}

/**
 * Membuat kumpulan fungsi CRUD standar untuk sebuah resource REST.
 * Menghindari duplikasi boilerplate fetch di setiap modul (items, suppliers, dst).
 */
export function createResourceApi<TEntity, TCreatePayload = Partial<TEntity>>(basePath: string) {
  return {
    list: (params?: ListParams) =>
      apiClient.get<PaginatedResult<TEntity>>(`${basePath}${buildQuery(params)}`),

    getById: (id: string) => apiClient.get<TEntity>(`${basePath}/${id}`),

    create: (payload: TCreatePayload) => apiClient.post<TEntity>(basePath, payload),

    update: (id: string, payload: Partial<TCreatePayload>) =>
      apiClient.put<TEntity>(`${basePath}/${id}`, payload),

    remove: (id: string) => apiClient.delete<void>(`${basePath}/${id}`),
  };
}
